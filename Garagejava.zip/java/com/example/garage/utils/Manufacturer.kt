package com.example.garage.utils

import com.example.garage.R

data class Manufacturer(
    val name: String,
    val address: String,
    val imageResource: Int,
    val url: String
)

val manufacturers = listOf(
    Manufacturer("Piaggo","Thiruvallur, Chennai ", R.drawable.piaggo,"https://piaggio-cv.co.in/"),
    Manufacturer("Mahindra","Maran nagar,Chennai ", R.drawable.mahindra,"https://mahindralastmilemobility.com/"),
    Manufacturer("Tata","Anna salai,Chennai ", R.drawable.tata_carbon,"https://www.magic.tatamotors.com/"),
    Manufacturer("Bajaj", "Arcot road,Chennai", R.drawable.bajaj,"https://www.bajajauto.com/three-wheelers/re"),
    Manufacturer("Toyota", "chromopet,Chennai", R.drawable.toyota_carbon,"https://www.toyotabharat.com/"),
    Manufacturer("Maruti Suziki", "Kattupakkam,Chennai", R.drawable.suzuki_carbon,"https://www.nexaexperience.com/"),
    Manufacturer("Honda", "Gerugambakkam,Chennai", R.drawable.honda_carbon,"https://www.hondacarindia.com/"),
    Manufacturer("Renault", "Pattabiram,Chennai", R.drawable.renault_carbon,"https://www.renault.co.in/"),
    Manufacturer("Volkswagen", "Ambattur,Chennai", R.drawable.volkswagen_logo,"https://www.volkswagen.co.in/en.html"),
    Manufacturer("Skoda", "Anna salai,Chennai", R.drawable.skoda_carbon,"https://www.skoda-auto.co.in/"),
    Manufacturer("Nissan", "Velacherry,Chennai", R.drawable.nissan_carbon,"https://www.nissan.in/"),
    Manufacturer("Yamaha", "Moulivakam,Chennai", R.drawable.yamaha_carbon,"https://www.yamaha-motor-india.com/"),
    Manufacturer("Suzuki", "Avadi,Chennai", R.drawable.suzuki_carbon,"https://www.suzukimotorcycle.co.in/"),
    Manufacturer("Ola", "Guduvucheri,Chennai", R.drawable.ola,"https://olaelectric.com/"),
    Manufacturer("Hero Honda", "kattupakkam,Chennai", R.drawable.honda_wing_carbon,"https://www.honda2wheelersindia.com/"),
    Manufacturer("Eicher", "Guduvucheri,Chennai", R.drawable.eicher,"https://www.eichertrucksandbuses.com/"),
    Manufacturer("Ashok Leyland", "Anna salai,Chennai", R.drawable.ashokleyland,"https://www.ashokleyland.com/in/en"),
    Manufacturer("Bharathbenz", "nandiyalam,Chennai", R.drawable.bharatbenz,"https://www.bharatbenz.com/"),
    Manufacturer("Hero","Kattupakkam,Chennai",R.drawable.herologo,"https://www.heromotocorp.com/en-in.html")
)

