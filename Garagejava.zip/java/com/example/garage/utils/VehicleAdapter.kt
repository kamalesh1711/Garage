package com.example.garage.utils

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.garage.R
import com.google.android.material.imageview.ShapeableImageView

class VehicleAdapter(private val bikelist: List<Vehicle>) :
    RecyclerView.Adapter<VehicleAdapter.ViewHolder>() {
    private lateinit var mListener: onItemClickListener

    interface onItemClickListener {
        fun onItemClick(position: Int)
    }

    fun setOnItemClickListener(listener: onItemClickListener) {
        mListener = listener
    }

     class ViewHolder(itemView: View, listener: onItemClickListener) :
        RecyclerView.ViewHolder(itemView) {
        val titleImage: ShapeableImageView = itemView.findViewById(R.id.bcomp)
        val heading: TextView = itemView.findViewById(R.id.tvbik)
        val add: TextView = itemView.findViewById(R.id.textView6)

        init {
            itemView.setOnClickListener {
                listener.onItemClick(adapterPosition)
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.list_bike, parent, false)
        return ViewHolder(itemView, mListener)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = bikelist[position]
        holder.titleImage.setImageResource(item.imageResource)
        holder.heading.text = item.name
        holder.add.text = item.price+".RS, Ex-Showroom Chennai"
    }

    override fun getItemCount(): Int {
        return bikelist.size
    }
}