package com.example.garage

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.garage.utils.ManufacturerAdapter
import com.example.garage.utils.manufacturers
import com.example.garage.utils.vehicles

class ManufacturerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_car)

        val bundle = intent.extras
        val type = bundle!!.getString("type")
        println("type: $type")

        val vehicles = vehicles.filter { it.type == type }
        val manufacturerNames = vehicles.map { it.manufacturerName }
        val data = manufacturers.filter { manufacturerNames.contains(it.name) }

        var r: RecyclerView =findViewById(R.id.rvc)

        var a= ManufacturerAdapter(data)
        r.adapter=a
        r.layoutManager= LinearLayoutManager(this)
        r.setHasFixedSize(true)
        a.setOnItemClickListener(object : ManufacturerAdapter.onItemClickListener{
            override fun onItemClick(position: Int) {
                var intent = Intent(this@ManufacturerActivity,VehicleActivity::class.java)
                intent.putExtra("manufacturer", data[position].name)
                intent.putExtra("url",data[position].url)
                intent.putExtra("type",type)
                startActivity(intent)
            }
        })
    }
}