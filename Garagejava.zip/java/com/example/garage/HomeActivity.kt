package com.example.garage

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.google.firebase.auth.FirebaseAuth
import java.lang.StringBuilder

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        var car=findViewById<ImageView>(R.id.car)
        var bike=findViewById<ImageView>(R.id.bike)
        var auto=findViewById<ImageView>(R.id.auto)
        var truck=findViewById<ImageView>(R.id.truck)

        var text=findViewById<TextView>(R.id.textView5)
        var name1=findViewById<TextView>(R.id.tv1)
        var bts=findViewById<Button>(R.id.button2)

        val user=intent.getStringExtra("user_id")
        val email=intent.getStringExtra("email_id")

        var name=email.toString().substring(0,email.toString().lastIndexOf("@"));
        name1.text="Hii "+name+" ."
        var display=StringBuilder()
        display.append("You Successfully Logged in. \n")
        text.text=display

        car.setOnClickListener{
            startManufacturerActivity("car")
        }

        bike.setOnClickListener{
            startManufacturerActivity("bike")
        }

        auto.setOnClickListener{
            startManufacturerActivity("auto")
        }

        truck.setOnClickListener{
            startManufacturerActivity("truck")
        }

        bts.setOnClickListener{
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this@HomeActivity,MainActivity::class.java))
            finish()
        }
    }

     fun startManufacturerActivity(type: String) {
         val intent = Intent(this, ManufacturerActivity::class.java)
         intent.putExtra("type", type)
         startActivity(intent)
     }
}