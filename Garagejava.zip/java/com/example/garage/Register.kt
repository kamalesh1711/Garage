package com.example.garage

import android.content.Intent
import   androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class Register : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        var btn=findViewById<Button>(R.id.buttonr)
        var eml=findViewById<EditText>(R.id.editTextText)
        var pwd=findViewById<EditText>(R.id.editTextTextPassword)
        var log=findViewById<TextView>(R.id.textView4)
        log.setOnClickListener{
            startActivity(Intent(this@Register,MainActivity::class.java))
        }
        btn.setOnClickListener{
            when{
                TextUtils.isEmpty(eml.text.toString().trim{ it <= ' '})->{
                    Toast.makeText(this@Register,"Please enter Email",Toast.LENGTH_SHORT).show()
                }

                TextUtils.isEmpty(pwd.text.toString().trim{ it <= ' '})->{
                    Toast.makeText(this@Register,"Please enter Password",Toast.LENGTH_SHORT).show()
                }
                else -> {
                    val email: String = eml.text.toString().trim{ it <= ' ' }
                    val password: String = pwd.text.toString().trim{ it <= ' ' }

                    FirebaseAuth.getInstance().createUserWithEmailAndPassword(email,password)
                        .addOnCompleteListener{ task ->
                            if (task.isSuccessful) {
                                val firebaseUser: FirebaseUser = task.result!!.user!!

                                Toast.makeText(
                                    this@Register,
                                    "You are registered successfully",
                                    Toast.LENGTH_SHORT
                                ).show()

                                val intent=Intent(this,HomeActivity::class.java)
                                intent.flags=Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                intent.putExtra("user_id",firebaseUser.uid)
                                intent.putExtra("email_id",email)
                                startActivity(intent)
                                finish()
                            }else{
                                Toast.makeText(this@Register,task.exception!!.message.toString(),Toast.LENGTH_SHORT).show()
                            }
                        }
                }
            }
        }
    }
}