package com.example.garage

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.garage.utils.VehicleAdapter
import com.example.garage.utils.vehicles
import java.lang.StringBuilder

class VehicleActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bajaj)
        var bundle: Bundle? = intent.extras
//        var url=bundle!!.getString("url")
        val name = bundle!!.getString("manufacturer")
        val link = bundle!!.getString("url")
        val type=bundle!!.getString("type")
        val list = vehicles.filter { it.manufacturerName == name }
        val list2=list.filter { it.type==type }
        var rec: RecyclerView = findViewById(R.id.rvmo)
        var share=findViewById<Button>(R.id.share)

        rec.layoutManager = LinearLayoutManager(this)
        rec.setHasFixedSize(true)
        val adapter = VehicleAdapter(list2)
        rec.adapter = adapter

        val builder=StringBuilder()
        adapter.setOnItemClickListener(object : VehicleAdapter.onItemClickListener {
            //        if (url != null) {
//            web.loadUrl(url)
//        }
            override fun onItemClick(position: Int) {
//                var int = Intent(this@VehicleActivity, Fav::class.java)
//                int.putExtra("veh", list[position].name)
//                int.putExtra("pric", list[position].price)
//                startActivity(int)
                var nam=list2[position].name
                var pric=list2[position].price
                Toast.makeText(this@VehicleActivity,"You selected $nam",Toast.LENGTH_SHORT).show()
                builder.append("$nam:$pric. \n")

            }
        })
      
        share.setOnClickListener{
            var int1=Intent()
            int1.action=Intent.ACTION_SEND
            int1.putExtra(Intent.EXTRA_TEXT,link)
            int1.type="text/plain"
            startActivity(Intent.createChooser(int1,"Share the link via"))
        }

        }

    }

//if (url != null) {
//    web.loadUrl(url)
// }
//share.setOnClickListener{
//   var intent=Intent()
// intent.action=Intent.ACTION_SEND
// intent.putExtra(Intent.EXTRA_TEXT,url)
//intent.type="text/plain"
//startActivity(Intent.createChooser(intent,"share the link via"))