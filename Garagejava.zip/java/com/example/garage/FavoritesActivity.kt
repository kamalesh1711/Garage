package com.example.garage

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class FavoritesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fav)
        var tex=findViewById<TextView>(R.id.textView7)
        var bundle: Bundle? = intent.extras
        var build=bundle!!.getString("favour")

        tex.text==build
    }
}